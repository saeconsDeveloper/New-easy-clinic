// middlewares/authMiddleWare.js
const jwt = require("jsonwebtoken");
const JWT_SECRET = process.env.JWT_SECRET || "yourSecretKey";

function authenticateToken(requiredTypeOrRoles) {
  const roles =
    requiredTypeOrRoles == null
      ? null
      : Array.isArray(requiredTypeOrRoles)
      ? requiredTypeOrRoles
      : [requiredTypeOrRoles]; // ← backward-compatible

  return function (req, res, next) {
    const bearer = (req.headers.authorization || "").replace(/^Bearer\s+/i, "");
    const token = req.cookies?.DMCToken || bearer;

    if (!token) return res.redirect("/login");

    jwt.verify(token, JWT_SECRET, (err, payload) => {
      if (err) return res.redirect("/login");

      // role/type compatibility
      if (roles) {
        const userRole = payload.role || payload.type;
        if (!roles.includes(userRole)) return res.redirect("/login");
      }

      // no-cache
      res.setHeader("Cache-Control", "no-store");
      res.setHeader("Pragma", "no-cache");
      res.setHeader("Expires", "0");

      req.user = payload;
      next();
    });
  };
}

// Optional helpers (don’t break existing default export)
function requireAuth(req, res, next) {
  return authenticateToken()(req, res, next);
}
function requireRole(...roles) {
  return authenticateToken(roles);
}

module.exports = authenticateToken;          // default export (old usage keeps working)
module.exports.requireAuth = requireAuth;    // new optional helper
module.exports.requireRole = requireRole;    // new optional helper
