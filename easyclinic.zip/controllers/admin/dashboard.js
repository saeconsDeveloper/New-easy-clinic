"use strict";

const asyncHandler = require("../../middlewares/async");
const ExcelJS = require("exceljs");
const puppeteer = require("puppeteer");

const patient = require("../../models/entities/patient");
const diagnose = require("../../models/entities/diagnose");
const labReport = require("../../models/entities/labReport");

const { findAllPatientCount, deleteDiagnose: ucDeleteDiagnose } = require("../../models/useCases/diagnose");
const { createLabReport, findOneReport, deleteReport: ucDeleteReport } = require("../../models/useCases/labReport");
const { deletePatient: ucDeletePatient } = require("../../models/useCases/patients");

const { getTemporaryUrl, uploadFileToS3 } = require("../../utils/s3");
const sequelize = require("../../configs/database");
const ErrorResponse = require("../../utils/errorResponse");

// Auth-related (for checkPassword)
const jwt = require("jsonwebtoken");
const Clinic = require("../../models/entities/clinic");
const bcrypt = require("bcryptjs");

// Helpers
const slug = (s = "") =>
  String(s).toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
exports.changePasswordPage = (req, res) => {
  const role = (req.user?.clinicRole || (req.user?.type === "upload" ? "ADMIN" : "VIEWER"));
  res.render("changePassword", { error: null, success: null, role });
};

// POST: change password using current -> new -> confirm
exports.changePasswordPost = async (req, res) => {
  try {
    const { currentPassword, newPassword, confirmPassword } = req.body;
    const clinicId = req.user?.clinicId;
    const role = (req.user?.clinicRole || (req.user?.type === "upload" ? "ADMIN" : "VIEWER")).toUpperCase();

    if (!clinicId) {
      return res.status(401).render("changePassword", { error: "Not authenticated", success: null, role });
    }
    if (!currentPassword || !newPassword || !confirmPassword) {
      return res.status(400).render("changePassword", { error: "All fields are required", success: null, role });
    }
    if (newPassword !== confirmPassword) {
      return res.status(400).render("changePassword", { error: "New passwords do not match", success: null, role });
    }
    if (newPassword.length < 8) {
      return res.status(400).render("changePassword", { error: "New password must be at least 8 characters", success: null, role });
    }

    const clinic = await Clinic.findByPk(clinicId);
    if (!clinic) {
      return res.status(404).render("changePassword", { error: "Clinic not found", success: null, role });
    }

    const currentHash = role === "ADMIN" ? clinic.adminPasswordHash : clinic.viewerPasswordHash;
    if (!currentHash) {
      return res.status(400).render("changePassword", { error: "Password not set yet for this role", success: null, role });
    }

    const ok = await bcrypt.compare(currentPassword, currentHash);
    if (!ok) {
      return res.status(401).render("changePassword", { error: "Current password is incorrect", success: null, role });
    }
    const same = await bcrypt.compare(newPassword, currentHash);
    if (same) {
      return res.status(400).render("changePassword", { error: "New password must be different from current password", success: null, role });
    }

    const newHash = await bcrypt.hash(newPassword, 10);
    if (role === "ADMIN") clinic.adminPasswordHash = newHash;
    else clinic.viewerPasswordHash = newHash;

    await clinic.save();

    // Optional: force re-login after change
    res.clearCookie("DMCToken");
    return res.render("changePassword", {
      error: null,
      success: "Password updated. Please log in again.",
      role,
    });
  } catch (e) {
    console.error(e);
    return res.status(500).render("changePassword", { error: "Something went wrong", success: null, role: (req.user?.clinicRole || "").toUpperCase() });
  }
};
/* =========================
   Excel -> JSON extraction
   ========================= */
exports.excelUpload = asyncHandler(async (req, res) => {
  try {
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(req.file.buffer);

    const sheet = workbook.worksheets[0];
    const patientDetails = {};
    const diagnosisRecords = [];

    let startRow = 1;
    const rowCount = sheet.rowCount;

    // Identify Patient Details (Name, Birthdate, Address)
    for (let i = 1; i <= rowCount; i++) {
      const row = sheet.getRow(i);
      const firstCell = String(row.getCell(1).value || "").toLowerCase().trim();

      // Name
      if (["name", "name:", "Name", "Name:", "Name :"].includes(firstCell)) {
        for (let col = 2; col <= 4; col++) {
          const cellValue = String(row.getCell(col).value || "").trim();
          if (!["name", "name:", "Name", "Name:", "Name :"].includes(cellValue) && cellValue) {
            patientDetails.name = cellValue;
            break;
          }
        }
        continue;
      }

      // Birthdate
      if (
        ["birthdate", "birthdate:", "Birthdate", "Birthdate:", "Birthdate :", "Date of Birth", "Date of Birth:"].includes(
          firstCell
        )
      ) {
        for (let col = 2; col <= 4; col++) {
          const cellValue = String(row.getCell(col).value || "").trim();
          if (
            !["birthdate", "birthdate:", "Birthdate", "Birthdate:", "Birthdate :"].includes(cellValue) &&
            cellValue
          ) {
            const rawBirthdate = cellValue ?? null;
            if (rawBirthdate) {
              const yearMatch = String(rawBirthdate).match(/\b\d{4}\b/);
              patientDetails.birthdate = yearMatch ? parseInt(yearMatch[0]) : null;
            } else {
              patientDetails.birthdate = null;
            }
            break;
          }
        }
        continue;
      }

      // Address
      if (["adress", "adress:", "Adress", "Adress:", "Adress :"].includes(firstCell)) {
        for (let col = 2; col <= 4; col++) {
          const cellValue = String(row.getCell(col).value || "").trim();
          if (!["adress", "adress:", "Adress", "Adress:", "Adress :"].includes(cellValue) && cellValue) {
            patientDetails.address = cellValue;
            break;
          }
        }
        startRow = i + 2;
        continue;
      }
    }

    // Step 2: Extract Diagnosis & Treatment Details
    for (let i = startRow; i <= rowCount; i++) {
      const row = sheet.getRow(i);
      const firstCell = row.getCell(1).value || "";

      // Identify rows that begin with a date pattern (e.g., "28/1/08" or actual Date objects)
      const looksLikeDate =
        firstCell instanceof Date || (String(firstCell).split("/").length - 1) >= 2;

      if (looksLikeDate) {
        let date;

        // Convert to ISO if real Date
        if (firstCell instanceof Date && !isNaN(firstCell)) {
          date = firstCell.toISOString();
        } else {
          // Handle textual dates like "28/Jan/08" or "28/1/08"
          const parts = String(firstCell).split("/").filter((p) => p.trim() !== "");
          if (parts?.length === 2 || parts?.length === 3) {
            let [day, monthInput, yearRaw] = parts.map((p) => p.trim());
            const year = `20${yearRaw ? yearRaw.slice(-2) : "00"}` || "2000";
            let nextYear = false;
            if (year === "2000") nextYear = true;

            day = day ? day.padStart(2, "0") : "01";
            const monthMap = {
              january: ["jan", "january", "01", "1", "janv", "janvier"],
              february: ["feb", "february", "02", "2", "fev", "fevr", "fevrier"],
              march: ["mar", "march", "03", "3", "mars"],
              april: ["apr", "april", "04", "4", "avril", "avr"],
              may: ["may", "05", "5", "mai"],
              june: ["jun", "june", "06", "6", "juin"],
              july: ["jul", "july", "07", "7", "juil", "juillet"],
              august: ["aug", "august", "08", "8", "aout"],
              september: ["sep", "sept", "september", "09", "9", "septembre"],
              october: ["oct", "october", "10", "octobre"],
              november: ["nov", "november", "11", "novembre"],
              december: ["dec", "december", "12", "decembre"],
            };
            let month = "01";
            for (const [key, values] of Object.entries(monthMap)) {
              if (values.map((v) => v.toLowerCase()).includes(String(monthInput).toLowerCase())) {
                const monthNumber = Object.keys(monthMap).indexOf(key) + 1;
                month = String(monthNumber).padStart(2, "0");
                break;
              }
            }
            if (year && month && day) {
              date = new Date(`${year}-${month}-${day}`).toISOString();
            }

            // Merge multiline diagnosis/treatment until next date row
            let diagnosis = "";
            let treatment = "";
            const diagnoseSet = new Set();
            const treatmentSet = new Set();

            // current row col B..F -> diagnosis, G..I -> treatment
            for (let col = 2; col <= 6; col++) {
              const value = String(row.getCell(col).value || "").trim();
              if (value) diagnoseSet.add(value);
            }
            for (const x of diagnoseSet) diagnosis += x + " ";
            diagnosis += "\n";
            diagnoseSet.clear();

            for (let col = 7; col <= 9; col++) {
              const value = String(row.getCell(col).value || "").trim();
              if (value) treatmentSet.add(value);
            }
            for (const x of treatmentSet) treatment += x + " ";
            treatment += "\n";
            treatmentSet.clear();

            let j = i + 1;
            while (j <= rowCount) {
              const nextRow = sheet.getRow(j);
              const nextFirst = nextRow.getCell(1).value || "";

              const nextLooksLikeDate =
                nextFirst instanceof Date || (String(nextFirst).split("/").length - 1) >= 2;
              if (nextLooksLikeDate) break;

              if (nextYear) {
                const input = String(nextFirst).trim();
                const match = input.match(/\b(20\d{2})\b/);
                if (match) {
                  const y = match[1];
                  const d = new Date(date);
                  d.setUTCFullYear(parseInt(y, 10));
                  date = d.toISOString();
                  nextYear = false;
                }
              }

              for (let col = 2; col <= 6; col++) {
                const value = String(nextRow.getCell(col).value || "").trim();
                if (value) diagnoseSet.add(value);
              }
              for (const x of diagnoseSet) diagnosis += x + " ";
              diagnosis += "\n";
              diagnoseSet.clear();

              for (let col = 7; col <= 9; col++) {
                const value = String(nextRow.getCell(col).value || "").trim();
                if (value) treatmentSet.add(value);
              }
              for (const x of treatmentSet) treatment += x + " ";
              treatment += "\n";
              treatmentSet.clear();

              j++;
            }

            diagnosisRecords.push({
              date,
              diagnosis: diagnosis.trim(),
              treatment: treatment.trim(),
            });

            i = j - 1; // Skip to next record
          }
        }
      }
    }

    res.json({
      success: true,
      patientDetails,
      diagnosisRecords,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({
      success: false,
      message: "Failed to process Excel file",
    });
  }
});

/* =========================
   Patients list (with paging)
   ========================= */
exports.findAllPatients = asyncHandler(async (req, res, next) => {
  let {
    from,
    to,
    searchPatientName,
    searchPatientAddress,
    searchPatientMobileNo,
    searchTreatment,
    searchDiagnose,
    birthdateFrom,
    birthdateTo,
    page,
    limit,
  } = req.query;

  const sort = req.query.sort && req.query.sort === "ASC" ? "ASC" : "DESC";
  let sortField = req.query.sortField || "createdAt";

  const params = {
    from,
    to,
    searchPatientName,
    searchPatientAddress,
    searchPatientMobileNo,
    searchTreatment,
    searchDiagnose,
    birthdateFrom,
    birthdateTo,
    sort,
    sortField,
    page,
    limit,
  };

  const transactionsData = await findAllPatientCount(params);
  if (!transactionsData) {
    return next(new ErrorResponse(`Something went wrong while getting all client from DB`, 500));
  } else {
    const { paginatedResults, currentPage, currentLimit, totalCount } = transactionsData;
    return res.status(200).json({
      status: true,
      data: {
        data: paginatedResults,
        pagination: {
          total: totalCount,
          page: currentPage,
          limit: currentLimit,
          totalPages: Math.ceil(totalCount / currentLimit),
        },
      },
      message: "Client fetched successfully",
      responseCode: "000",
    });
  }
});

/* =========================
   Save (create patient + diagnoses)
   ========================= */
exports.saveAllPatients = asyncHandler(async (req, res) => {
  const { patientDetails, diagnosisRecords } = req.body;
  let transaction;
  try {
    transaction = await sequelize.transaction();

    const Patient = await patient.create(
      {
        name: patientDetails.name == "" ? null : patientDetails.name,
        birthdate: patientDetails.birthdate == "" ? null : patientDetails.birthdate,
        address: patientDetails.address == "" ? null : patientDetails.address,
      },
      { transaction }
    );

    for (const record of diagnosisRecords) {
      await diagnose.create(
        {
          patientId: Patient.id,
          date: record.date,
          diagnosis: record.diagnosis,
          treatment: record.treatment,
        },
        { transaction }
      );
    }

    await transaction.commit();
    res.status(200).json({ message: "Data saved successfully" });
  } catch (err) {
    if (transaction) await transaction.rollback();
    console.error(err);
    res.status(500).json({ error: "Failed to save data" });
  }
});

/* =========================
   Edit (update patient + diagnoses)
   ========================= */
exports.saveEditPatients = asyncHandler(async (req, res) => {
  const { patientDetails, diagnosisRecords } = req.body;
  let transaction;
  try {
    transaction = await sequelize.transaction();

    await patient.update(
      {
        name: patientDetails.name == "" ? null : patientDetails.name,
        birthdate: patientDetails.birthdate == "" ? null : patientDetails.birthdate,
        address: patientDetails.address == "" ? null : patientDetails.address,
        mobileNo:
          patientDetails.mobileNo == "" || patientDetails.mobileNo == null ? null : patientDetails.mobileNo,
      },
      { where: { id: patientDetails.id }, transaction }
    );

    for (const record of diagnosisRecords) {
      await diagnose.update(
        {
          patientId: patientDetails.id, // <- use the id you already have
          date: record.date,
          diagnosis: record.diagnosis,
          treatment: record.treatment,
        },
        { where: { id: record.id }, transaction }
      );
    }

    await transaction.commit();
    res.status(200).json({ message: "Data saved successfully" });
  } catch (err) {
    if (transaction) await transaction.rollback();
    console.error(err);
    res.status(500).json({ error: "Failed to save data" });
  }
});

/* =========================
   Lab Report upload / delete
   ========================= */
exports.uploadReport = asyncHandler(async (req, res, next) => {
  const { patientId, diagnoseId } = req.body;
  const files = req.files;

  if (!files || files.length === 0) {
    return next(new ErrorResponse(`At least one file is required`, 400));
  }

  const result = await createLabReport(files, patientId, diagnoseId);
  if (!result) {
    return next(new ErrorResponse(`Something went wrong while creating`, 500));
  } else {
    const uploadedDetails = await Promise.all(
      result.map(async (report) => {
        const presigned = await getTemporaryUrl(report.key);
        return {
          id: report.id,
          fileName: report.fileName,
          url: presigned?.url || null,
        };
      })
    );

    return res.status(200).json({
      status: true,
      message: "Report created successfully",
      data: { data: uploadedDetails },
      responseCode: "000",
    });
  }
});

exports.deleteReport = asyncHandler(async (req, res, next) => {
  const params = req.params;

  const details = await findOneReport(params);
  if (!details) {
    return next(new ErrorResponse(`Something went wrong while fetching reports`, 404));
  }

  const result = await ucDeleteReport(params, details?.key);
  if (result === 0) {
    return next(new ErrorResponse(`Something went wrong while deleting reports`, 404));
  } else {
    return res.status(200).json({
      status: true,
      data: {},
      message: "Report deleted successfully",
      responseCode: "000",
    });
  }
});

/* =========================
   Delete diagnose / patient
   ========================= */
exports.deleteDiagnose = asyncHandler(async (req, res, next) => {
  const result = await ucDeleteDiagnose(req.params);
  if (result === 0) {
    return next(new ErrorResponse(`Something went wrong while deleting diagnose`, 404));
  } else {
    return res.status(200).json({
      status: true,
      data: {},
      message: "Diagnose deleted successfully",
      responseCode: "000",
    });
  }
});

exports.deletePatient = asyncHandler(async (req, res, next) => {
  const result = await ucDeletePatient(req.params);
  if (result === 0) {
    return next(new ErrorResponse(`Something went wrong while deleting patient`, 404));
  } else {
    return res.status(200).json({
      status: true,
      data: {},
      message: "Patient deleted successfully",
      responseCode: "000",
    });
  }
});

/* =========================
   Add diagnoses (+ optional files)
   ========================= */
exports.saveAddDiagonsis = asyncHandler(async (req, res) => {
  const files = req.files || [];
  const body = req.body;

  const fileMap = {};
  files.forEach((file) => {
    const match = file.fieldname.match(/diagnoses\[(\d+)\]\[files\]/);
    if (match) {
      const index = parseInt(match[1], 10);
      if (!fileMap[index]) fileMap[index] = [];
      fileMap[index].push(file);
    }
  });

  const results = [];

  if (!body.diagnoses || !Array.isArray(body.diagnoses)) {
    return res.status(400).json({
      success: false,
      message: "No diagnoses data provided or invalid format",
    });
  }

  for (const [index, diagnosisData] of body.diagnoses.entries()) {
    const { date, diagnosis, treatment, patientId } = diagnosisData;

    if (!date || !patientId) {
      return res.status(400).json({
        success: false,
        message: `Missing required fields for diagnosis at index ${index}`,
      });
    }

    const diagnosisRecord = await diagnose.create({
      patientId,
      date,
      diagnosis,
      treatment,
    });

    const uploadedFiles = [];
    if (fileMap[index]) {
      for (const file of fileMap[index]) {
        const filePath = `labReports/${patientId}`;
        const { key, fileName } = await uploadFileToS3(file, filePath);

        const LabReport = await labReport.create({
          diagnoseId: diagnosisRecord.id,
          key,
          fileName,
        });

        uploadedFiles.push(LabReport.dataValues);
      }
    }

    results.push({
      ...diagnosisRecord.dataValues,
      files: uploadedFiles,
    });
  }

  res.status(200).json({
    success: true,
    data: results,
  });
});

/* =========================
   Add new patient only
   ========================= */
exports.addNewPatient = asyncHandler(async (req, res) => {
  const { patientDetails } = req.body;
  let transaction;
  try {
    transaction = await sequelize.transaction();

    await patient.create(
      {
        name: patientDetails.name == "" ? null : patientDetails.name,
        birthdate: patientDetails.birthdate == "" ? null : patientDetails.birthdate,
        address: patientDetails.address == "" ? null : patientDetails.address,
        mobileNo:
          patientDetails.mobileNo == "" || patientDetails.mobileNo == null ? null : patientDetails.mobileNo,
      },
      { transaction }
    );

    await transaction.commit();
    res.status(200).json({ message: "Data saved successfully" });
  } catch (err) {
    if (transaction) await transaction.rollback();
    console.error(err);
    res.status(500).json({ error: "Failed to save data" });
  }
});

/* =========================
   Login by clinic code + role password
   ========================= */
exports.checkPassword = async (req, res) => {
  try {
    const { clinicCode, role, password } = req.body;
    const clinic = await Clinic.findOne({ where: { code: slug(clinicCode) } });
    if (!clinic) return res.status(401).render("login", { error: "Clinic not found" });

    const isAdmin = String(role).toUpperCase() === "ADMIN";
    const hash = isAdmin ? clinic.adminPasswordHash : clinic.viewerPasswordHash;
    if (!hash) return res.status(401).render("login", { error: "Account not set up yet" });

    const ok = await bcrypt.compare(password, hash);
    if (!ok) return res.status(401).render("login", { error: "Invalid password" });

    const token = jwt.sign(
      { clinicId: clinic.id, clinicRole: isAdmin ? "ADMIN" : "VIEWER", type: isAdmin ? "upload" : "view" },
      process.env.JWT_SECRET || "yourSecretKey",
      { expiresIn: "1d" }
    );
    res.cookie("DMCToken", token, {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
    });
    return res.redirect(isAdmin ? "/upload" : "/view");
  } catch (e) {
    console.error(e);
    return res.status(500).render("login", { error: "Something went wrong" });
  }
};

/* =========================
   Export PDF via Puppeteer
   ========================= */
exports.exportPDF = asyncHandler(async (req, res) => {
  try {
    let {
      from,
      to,
      searchPatientName,
      searchPatientAddress,
      searchPatientMobileNo,
      searchTreatment,
      searchDiagnose,
      birthdateFrom,
      birthdateTo,
      page,
      limit,
    } = req.query;

    const sort = req.query.sort && req.query.sort === "ASC" ? "ASC" : "DESC";
    const sortField = req.query.sortField || "createdAt";

    const params = {
      from,
      to,
      searchPatientName,
      searchPatientAddress,
      searchPatientMobileNo,
      searchTreatment,
      searchDiagnose,
      birthdateFrom,
      birthdateTo,
      sort,
      sortField,
      page,
      limit,
    };

    const transactionsData = await findAllPatientCount(params);
    const { paginatedResults } = transactionsData;

    const browser = await puppeteer.launch({
      headless: "new",
      args: ["--no-sandbox", "--disable-setuid-sandbox"],
    });
    const webPage = await browser.newPage();

    const html = htmlPDF(paginatedResults, params);
    await webPage.setContent(html, { waitUntil: "networkidle0" });

    const pdfBuffer = await webPage.pdf({
      format: "A4",
      printBackground: true,
      displayHeaderFooter: true,
      margin: { top: "40px", bottom: "40px" },
      headerTemplate: `
        <style>
          .header { font-size: 10px; width: 100%; display: flex; justify-content: space-between; padding: 0 40px; margin: 0; }
        </style>
        <div class="header">
          <span>Page <span class="pageNumber"></span></span>
          <span>Dr. Randa Yehia y/82</span>
        </div>
      `,
      footerTemplate: `
        <style>
          .footer { font-size: 10px; width: 100%; text-align: center; padding: 0; margin: 0; }
        </style>
        <div class="footer">
          <span>© Digital Med Clinic - <span class="date"></span></span>
        </div>
      `,
    });

    await browser.close();

    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", "attachment; filename=report.pdf");
    res.send(pdfBuffer);
  } catch (err) {
    console.error("Error generating PDF:", err);
    res.status(500).send("Failed to generate PDF");
  }
});

function htmlPDF(patients, params) {
  const cross = `<svg xmlns="http://www.w3.org/2000/svg" fill="#FF0000" width="20px" height="20px" viewBox="0 0 32 32"><path d="M18.8,16l5.5-5.5c0.8-0.8,0.8-2,0-2.8l0,0C24,7.3,23.5,7,23,7c-0.5,0-1,0.2-1.4,0.6L16,13.2l-5.5-5.5  c-0.8-0.8-2.1-0.8-2.8,0C7.3,8,7,8.5,7,9.1s0.2,1,0.6,1.4l5.5,5.5l-5.5,5.5C7.3,21.9,7,22.4,7,23c0,0.5,0.2,1,0.6,1.4  C8,24.8,8.5,25,9,25c0.5,0,1-0.2,1.4-0.6l5.5-5.5l5.5,5.5c0.8,0.8,2.1,0.8,2.8,0c0.8-0.8,0.8-2.1,0-2.8L18.8,16z"/></svg>`;
  const tick = `<svg xmlns="http://www.w3.org/2000/svg" fill="#008000" height="16px" width="16px" viewBox="0 0 512 512"><polygon points="437.3,30 202.7,339.3 64,200.7 0,264.7 213.3,478 512,94 "/></svg>`;

  let addRow = "";

  const fromDate = params.from ? params.from.split("-").reverse().join("/") : "";
  const toDate = params.to ? params.to.split("-").reverse().join("/") : "";

  const pageN = Number(params.page || 1);
  const limitN = Number(params.limit || patients.length || 10);

  patients.forEach((patient, index) => {
    const { diagnoses } = patient;

    // Find latest visit date if diagnoses exist
    let lastVisitDate = "";
    if (diagnoses?.length) {
      let latestDate = diagnoses[0].date;
      for (let i = 1; i < diagnoses.length; i++) {
        if (new Date(diagnoses[i].date) > new Date(latestDate)) {
          latestDate = diagnoses[i].date;
        }
      }
      const dateObj = new Date(latestDate);
      lastVisitDate = `${String(dateObj.getDate()).padStart(2, "0")}/${String(
        dateObj.getMonth() + 1
      ).padStart(2, "0")}/${dateObj.getFullYear()}`;
    }

    const hasLabReports = diagnoses?.some((d) => Array.isArray(d.labReports) && d.labReports.length > 0);

    addRow += `
      <tr>
        <td>${(pageN - 1) * limitN + (index + 1)}</td>
        <td>${patient.name || ""}</td>
        <td>${patient.birthdate || ""}</td>
        <td>${patient.address || ""}</td>
        <td style="text-align: center;">${hasLabReports ? tick : cross}</td>
        <td style="text-align: center;">${lastVisitDate}</td>
      </tr>
    `;
  });

  return `
<!DOCTYPE html>
<html>
<head>
  <title>Report</title>
  <meta charset="UTF-8">
  <style>
    body { font-family: Arial, sans-serif; padding:0px 30px; background-color: #fff; }
    .patient-info-table { width: 100%; border-collapse: collapse; margin-bottom: 10px; }
    .patient-info-table td { padding: 6px 10px; font-size: 13px; }
    table { width: 100%; border-collapse: collapse; font-size: 13px; }
    th, td { border: 1px solid #ccc; padding: 8px 12px; text-align: left; }
    th { background-color: #f2f2f2; }
    tr:nth-child(even) { background-color: #f9f9f9; }
  </style>
</head>
<body>

<div class="patient-inf">
  <table class="patient-info-table" style="border: none;">
    <tr>
      <td style="width: 60%;"><strong>Patient Address:</strong> ${params.searchPatientAddress || ""}</td>
      <td style="width: 20%;"><strong>DOB From:</strong> ${params.birthdateFrom || ""}</td>
      <td style="width: 20%;"><strong>DOB To:</strong> ${params.birthdateTo || ""}</td>
    </tr>
  </table>
</div>

<div class="patient-info">
  <table class="patient-info-table" style="border: none;">
    <tr>
      <td style="width: 30%;"><strong>Diagnose:</strong> ${params.searchDiagnose || ""}</td>
      <td style="width: 30%;"><strong>Treatment:</strong> ${params.searchTreatment || ""}</td>
      <td style="width: 20%;"><strong>From:</strong> ${fromDate}</td>
      <td style="width: 20%;"><strong>To:</strong> ${toDate}</td>
    </tr>
  </table>
</div>

<table>
  <thead>
    <tr>
      <th>No</th>
      <th>Patient Name</th>
      <th>Patient DOB</th>
      <th>Patient Address</th>
      <th>Lab Report</th>
      <th>Last Visit</th>
    </tr>
  </thead>
  <tbody>
    ${addRow}
  </tbody>
</table>

</body>
</html>
`;
}
