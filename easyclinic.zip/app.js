require("dotenv").config();
const express = require("express");
const errorHandler = require("./middlewares/error");
const cors = require("cors");
const morgan = require("morgan");
const path = require("path");
const cookieParser = require("cookie-parser");
const { checkPassword } = require("./controllers/admin/dashboard");
const authenticateToken = require("./middlewares/authMiddleware");
const app = express();

// register new models so sequelize.sync sees them

require("./models/entities/clinic");


const PORT = process.env.PORT || 10000;

// View engine setup
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// Core middlewares
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(morgan(":method :url :status :response-time ms"));
app.use(express.static(path.join(__dirname, "public")));

// --- mount routes AFTER cookieParser/json ---
app.use(require("./routes/superadmin.auth"));   // ⬅️ add this
app.use("/api/v1", require("./routes/API/v1"));
app.use("/api/v1/superadmin", require("./routes/superadmin.api"));
app.use(require("./routes/superadmin.page"));

app.get("/login", (req, res) => {
  const role = (req.query.role || "VIEWER").toUpperCase();
  res.render("login", { error: null, role });
});


//change Password
const {
  checkPasswords,
  changePasswordPage,
  changePasswordPost,
} = require("./controllers/admin/dashboard");

app.get("/change-password", authenticateToken(), changePasswordPage);
app.post("/change-password", authenticateToken(), changePasswordPost);

// pages
app.get("/", (req, res) => res.render("index"));
app.get("/view", authenticateToken("view"), (req, res) => res.render("view"));
app.post("/login", checkPassword);
app.get("/login", (req, res) => res.render("login"));
app.get("/upload", authenticateToken("upload"), (req, res) => res.render("upload"));
app.get("/privacy-policy", (req, res) => res.render("privacyPolicy"));
app.get("/logout", (req, res) => { res.clearCookie("DMCToken"); res.redirect("/login"); });

// errors
app.use(errorHandler);
app.use((err, req, res, next) => {
  return res.status(err.status || 500).json({
    status: err.status || 500,
    message: "Internal Server Error",
    data: {},
    responseCode: "001",
  });
});

// Server
app.listen(PORT, "0.0.0.0", () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
