const express = require('express');
const { excelUpload, findAllPatients, saveAllPatients, saveEditPatients, uploadReport, deleteReport, deleteDiagnose, deletePatient, saveAddDiagonsis, addNewPatient, checkPassword, exportPDF } = require('../../../../controllers/admin/dashboard');
const router = express.Router({mergeParams:true})
const multer = require("multer");
const upload = multer({ storage: multer.memoryStorage() }); // Store files in memory

router.post('/',upload.single("file"), excelUpload)
router.get('/', findAllPatients)
router.post('/save', saveAllPatients)
router.put('/', saveEditPatients)
router.post('/add-diagnose', upload.any() , saveAddDiagonsis)
router.post('/add-patient' , addNewPatient)
router.post('/report',upload.array("files", 5), uploadReport)
router.delete('/report/:id', deleteReport)
router.delete('/diagnose/:id', deleteDiagnose)
router.delete('/patient/:id', deletePatient)
// router.post('/password', checkPassword)
router.get('/export', exportPDF)


module.exports = router;
