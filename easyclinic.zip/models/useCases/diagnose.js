const { Op, literal, where: sequelizeWhere } = require("sequelize");
const asyncHandler = require("../../middlewares/async");
const diagnose = require("../entities/diagnose");
const patient = require("../entities/patient");
const sequelize = require("../../configs/database");
const { getTemporaryUrl } = require("../../utils/s3");

exports.findAllPatientCount = asyncHandler(async (param) => {
const {   
  from,
  to,
  searchPatientName,
  searchPatientAddress,
  searchPatientMobileNo,
  searchTreatment,
  searchDiagnose,
  birthdateFrom,
  birthdateTo,
  sort,
  sortField,
  page,
  limit  } = param;
let req = {}
 const yourQuery = `
SELECT 
    p.id AS patientId,
    p.name AS name,
    p.birthdate AS birthdate,
    p.address AS address,
    p.createdAt AS patientCreatedAt,
    p.mobileNo AS mobileNumber,
    JSON_ARRAYAGG(
        JSON_OBJECT(
            'id', d.id,
            'date', d.date,
            'diagnosis', d.diagnosis,
            'treatment', d.treatment,
            'createdAt', d.createdAt,
            'labReports', (
                SELECT JSON_ARRAYAGG(
                    JSON_OBJECT(
                        'id', l.id,
                        'key', l.key,
                        'fileName', l.fileName,
                        'createdAt', l.createdAt
                    )
                )
                FROM neweasyClinic.labReports l
                WHERE l.diagnoseId = d.id
            )
        )
    ) AS diagnoses
FROM
    neweasyClinic.patients p
LEFT JOIN 
    neweasyClinic.diagnoses d ON d.patientId = p.id
WHERE
        (:searchPatientName IS NULL OR p.name LIKE CONCAT('%', :searchPatientName, '%'))
    AND (:searchPatientAddress IS NULL OR p.address LIKE CONCAT('%', :searchPatientAddress, '%'))
    AND (:searchPatientMobileNo IS NULL OR 
 REPLACE(REPLACE(REPLACE(p.mobileNo, '-', ''), '+', ''), ' ', '') LIKE 
 CONCAT('%', REPLACE(REPLACE(REPLACE(:searchPatientMobileNo, '-', ''), '+', ''), ' ', ''), '%'))
    AND (
        (:birthYearFrom IS NULL OR :birthYearTo IS NULL) 
        OR (
            YEAR(STR_TO_DATE(p.birthdate, '%Y-%m-%d')) BETWEEN :birthYearFrom AND :birthYearTo
        )
    )
    AND (:searchTreatment IS NULL OR d.treatment LIKE CONCAT('%', :searchTreatment, '%'))
    AND (:searchDiagnosis IS NULL OR d.diagnosis LIKE CONCAT('%', :searchDiagnosis, '%'))
    AND (:diagnoseDateFrom IS NULL OR DATE(d.date) >= :diagnoseDateFrom)
    AND (:diagnoseDateTo IS NULL OR DATE(d.date) <= :diagnoseDateTo)
GROUP BY 
    p.id
ORDER BY 
    p.createdAt DESC
`;

const results = await sequelize.query(yourQuery, {
  replacements: {
    searchPatientName: searchPatientName || null,
    searchPatientAddress: searchPatientAddress || null,
    searchPatientMobileNo: searchPatientMobileNo || null,
    birthYearFrom: ( birthdateFrom?.length === 4 && birthdateTo?.length === 4 && !isNaN(birthdateFrom) && !isNaN(birthdateTo) ) ?birthdateFrom : null,
    birthYearTo: ( birthdateFrom?.length === 4 && birthdateTo?.length === 4 && !isNaN(birthdateFrom) && !isNaN(birthdateTo) ) ? birthdateTo : null,
    searchTreatment: searchTreatment || null,
    searchDiagnosis: searchDiagnose || null,
    diagnoseDateFrom: from || null,
    diagnoseDateTo: to || null
  },
  type: sequelize.QueryTypes.SELECT
});

 // Total count before pagination
const totalCount = results.length;
// Apply pagination in JS
const currentPage = parseInt(page || '1');   
const currentLimit = parseInt(limit || '10');
const offset = (currentPage - 1) * currentLimit;
let paginatedResults = results.slice(offset, offset + currentLimit);

const processedPatients = [];

for (const patient of paginatedResults) {
  // Check if diagnoses array exists and has real entries
  if (Array.isArray(patient.diagnoses)) {
    // Remove diagnoses that are fully null
    const filteredDiagnoses = patient.diagnoses.filter(diagnosis => {
      // Check if all expected fields are null
      return !(diagnosis.id === null &&
               diagnosis.date === null &&
               diagnosis.createdAt === null &&
               diagnosis.diagnosis === null &&
               diagnosis.treatment === null &&
               diagnosis.labReports === null);
    });

    // If no valid diagnoses remain, set it to null
    if (filteredDiagnoses.length === 0) {
      patient.diagnoses = null;
    } else {
      // Otherwise process labReports for valid diagnoses
      for (const diagnosis of filteredDiagnoses) {
        if (Array.isArray(diagnosis.labReports) && diagnosis.labReports.length > 0) {
          const updatedReports = [];

          for (const report of diagnosis.labReports) {
            const result = await getTemporaryUrl(report.key); // async call
            updatedReports.push({
              ...report,
              url: result.url
            });
          }

          diagnosis.labReports = updatedReports;
        }
      }

      patient.diagnoses = filteredDiagnoses;
    }
  }

  processedPatients.push(patient);
}

return { paginatedResults: processedPatients, currentPage, currentLimit, totalCount };

  
  });


  module.exports.deleteDiagnose = asyncHandler(async (params) => {
    return await diagnose.destroy({
      where: {
        id: params.id,
      },
    });
});