"use strict";
const Sequelize = require("sequelize");
const sequelize = require("../../configs/database");

const Clinic = sequelize.define("clinics", {
  id: { type: Sequelize.INTEGER, autoIncrement: true, primaryKey: true },
  name: { type: Sequelize.STRING(191), allowNull: false },
  code: { type: Sequelize.STRING(64), allowNull: true, unique: true }, // slug used at login
  isActive: { type: Sequelize.BOOLEAN, allowNull: false, defaultValue: true },
  adminPasswordHash:  { type: Sequelize.STRING(191), allowNull: true },
  viewerPasswordHash: { type: Sequelize.STRING(191), allowNull: true },
}, { tableName: "clinics", timestamps: true });

module.exports = Clinic;
