"use strict";
const Sequelize = require("sequelize");
const sequelizeConfig = require("../../configs/database");
const patient = require("./patient");
const diagnose = sequelizeConfig.define("diagnose", {
  id: {
    type: Sequelize.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  date: Sequelize.DATE,
  diagnosis: Sequelize.TEXT,
  treatment: Sequelize.TEXT
});

diagnose.belongsTo(patient);

module.exports = diagnose;