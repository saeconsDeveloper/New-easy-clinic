"use strict";
const Sequelize = require("sequelize");
const sequelizeConfig = require("../../configs/database");
const diagnose = require("./diagnose");

const labReport = sequelizeConfig.define("labReport", {
  id: {
    type: Sequelize.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  key: Sequelize.TEXT,
  fileName: Sequelize.STRING,
  isActive: {
    type: Sequelize.BOOLEAN,
    defaultValue: true,
  },
});

labReport.belongsTo(diagnose);

module.exports = labReport;
