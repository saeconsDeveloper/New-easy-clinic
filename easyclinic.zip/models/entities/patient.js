// models/entities/patient.js
const { DataTypes } = require("sequelize");
const sequelize = require("../../configs/database");
const Clinic = require("./clinic");

const Patient = sequelize.define("patients", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  clinicId: { type: DataTypes.INTEGER, allowNull: false },
  name: DataTypes.STRING,
  birthdate: DataTypes.STRING,
  address: DataTypes.STRING,
  mobileNo: DataTypes.STRING,
}, {
  tableName: "patients",
  timestamps: true,
});

Patient.belongsTo(Clinic, { foreignKey: "clinicId" });

module.exports = Patient;
